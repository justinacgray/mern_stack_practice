import React from 'react'
import ProductForm from './ProductForm';

const CreateProduct = () => {
    return (
        <div>
            {/* <h3>Let's create a Product!</h3> */}
            <ProductForm/>
        </div>
    )
}

export default CreateProduct;
