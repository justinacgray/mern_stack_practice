import React, { useState, useEffect } from 'react'
import { Form, Button } from 'react-bootstrap'
import { Link, navigate } from '@reach/router';
import axios from 'axios';

const DeleteProduct = () => {
    return (
        <div>
            
        </div>
    )
}

export default DeleteProduct;
