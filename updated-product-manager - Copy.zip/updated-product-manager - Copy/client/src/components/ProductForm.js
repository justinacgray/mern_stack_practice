import React, { useState, useEffect } from 'react'
import AllProducts from './AllProducts'
import { Form, Button } from 'react-bootstrap'
import { Link, navigate } from '@reach/router';
import axios from 'axios';

const ProductForm = (props) => {
    //create state for the new product
    // const [ newProductItem, setNewProductItem ] = useState({
    //     title: "",
    //     price: 0,
    //     description: "",
    // })
    //handle the form submit to create item through API
    const { product } = props;
    // const inputChange = (e) => {
    //     console.log("input name: " + e.target.name);
    //     console.log("input value: " + e.target.value);
        
    //     let newProductObject = { ...newProductItem };
    //     newProductObject = [ e.target.name ] = e.target.value;
    //     setNewProductItem(newProductObject);
    // }
    const [ title, setTitle ] = useState("");
    const [ price, setPrice ] = useState(0);
    const [ description, setDescription ] = useState("");

    const [ errors, setErrors ] = useState({});

    const handleFormSubmit = (e) => {
        //the e (event) prevents the default
        e.preventDefault();
        // console.log(title, price, description);
        // call axios to post the object to my api
        axios.post("http://localhost:8000/api/products/new", {
            title : title,
            price : price,
            description :  description
        })
        //on success, redirect to product list
        .then((res) => {
            console.log(res.data);
            //if we have validation errors NOT errors with server
            if(res.data.error){
                setErrors(res.data.error.errors)
                // console.log("CHECKING SOMETHING");
            }
            else {
                // on success 
                navigate("/products/");
            }
        })
        //on failure, save errors in state so the user can correct the incorrect inputs
        .catch((err) => {
            console.log(err);
        })
    }
    

    return (
        <div>
            <h3> Create Product </h3>
            {/* labels for my inputs */}
            {/* inputs that update state as they change */}
            {/* values in the inputs that use state as the values */}
            {/* validate/ display erros that come from the backend server */}
            <Form onSubmit={handleFormSubmit}>
                <Form.Group className="mb-3" controlId="title">
                    <Form.Label>Title</Form.Label>
                    <Form.Control 
                    type="text" 
                    name="title" 
                    // value={newProductI.title}
                    onChange={ (e) => setTitle(e.target.value) }
                    placeholder="Title of item" />
                    {
                        errors.title ?
                        <span>{ errors.title.message }</span>
                        : null
                    }
                </Form.Group>

                <Form.Group className="mb-3" controlId="price">
                    <Form.Label>Price</Form.Label>
                    <Form.Control 
                    type="text" 
                    name="price" 
                    // value={newProductItem.price}
                    onChange={ (e) => setPrice(e.target.value) } 
                    placeholder="The cost of the item" />
                    {
                        errors.price ?
                        <span>{ errors.price.message }</span>
                        : null
                    }
                </Form.Group>

                <Form.Group className="mb-3" controlId="description">
                    <Form.Label>Description</Form.Label>
                    <Form.Control 
                    type="textarea" 
                    name="description" 
                    // value={newProductItem.description}
                    onChange={ (e) => setDescription(e.target.value) }
                    placeholder="Describe the item" as="textarea"/>
                    {
                        errors.description ?
                        <span>{ errors.description.message }</span>
                        : null
                    }
                </Form.Group>

                <Button variant="primary" type="submit">
                    Create Product
                </Button>

                <Button onClick={() => navigate("/products/")} variant="danger" type="submit">
                    Cancel
                </Button>
            </Form>

            {/* <AllProducts product="product" /> */}
        </div>
    );
}

export default ProductForm;
