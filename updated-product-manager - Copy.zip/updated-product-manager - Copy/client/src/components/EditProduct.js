import React, { useState, useEffect } from 'react'
import { Form, Button } from 'react-bootstrap'
import { Link, navigate } from '@reach/router';
import axios from 'axios';
// import ProductForm from './ProductForm'


const EditProduct = (props) => {

    const [ updatedTitle, setUpdatedTitle ] = useState("");
    const [ updatedPrice, setUpdatedPrice ] = useState(0);
    const [ updatedDescription, setUpdatedDescription ] = useState("");

    const [ productItem, setProductItem ] = useState({});

    const [ errors, setErrors ] = useState({});
    
    const updateProductForm = (e) => {
        //the e (event) prevents the default
        e.preventDefault();
        // console.log(title, price, description);
        // call axios to post the object to my api
        axios.put("http://localhost:8000/api/products/update/" + props._id, {
            title : updatedTitle,
            price: updatedPrice,
            description: updatedDescription,
        })
        //on success, redirect to product list
        .then((res) => {
            console.log(res.data);
            // if we have validation errors NOT errors with server
            if(res.data.error){
                setErrors(res.data.error.errors)
            }
            else {
                // on success 
                navigate("/products/");
            }
        })
        //on failure, save errors in state so the user can correct the incorrect inputs
        .catch((err) => {
            console.log(err);
        })
}

    // useEffect(() => {
    //     axios.get("http://localhost:8000/api/products/" + props._id)
    //     .then((res) => {
    //     console.log(res.data);
    //     //set the new data in our state from my api
    //     setProductItem(res.data.product); // needded to add .products my response was a new object with a key of products and the value is the array of product objects
    //     })
    //     .catch((err) => {
    //     console.log(err);
    //     })
    // }, [props._id]);

    useEffect(() => {
        axios.get("http://localhost:8000/api/products/" + props._id)
        .then(res => {
            console.log(res);
            setUpdatedTitle(res.data.product.title)
            setUpdatedPrice(res.data.product.price)
            setUpdatedDescription(res.data.product.description)
        })
    }, [props._id]);

    return (
        <div>
            <h3> Edit { updatedTitle }</h3>
            <Form onSubmit={updateProductForm}>
                <Form.Group className="mb-3" controlId="title">
                    <Form.Label>Title</Form.Label>
                    <Form.Control 
                    type="text" 
                    name="title" 
                    value={updatedTitle}
                    onChange={(e)=>setUpdatedTitle(e.target.value)} />
                    {
                        errors.title ?
                        <span>{ errors.title.message }</span>
                        : null
                    }
                </Form.Group>

                <Form.Group className="mb-3" controlId="price">
                    <Form.Label>Price</Form.Label>
                    <Form.Control 
                    type="text" 
                    name="price" 
                    value={updatedPrice}
                    onChange={(e)=>setUpdatedPrice(e.target.value)} />
                    {
                        errors.price ?
                        <span>{ errors.price.message }</span>
                        : null
                    }
                </Form.Group>

                <Form.Group className="mb-3" controlId="description">
                    <Form.Label>Description</Form.Label>
                    <Form.Control 
                    type="textarea" 
                    name="description" 
                    value={updatedDescription}
                    onChange={(e)=>setUpdatedDescription(e.target.value)} as="textarea"/>
                    {
                        errors.description ?
                        <span>{ errors.description.message }</span>
                        : null
                    }
                </Form.Group>

                <Button variant="primary" type="submit">
                    Update
                </Button>

                <Button onClick={() => navigate("/products/new")} variant="danger" type="submit">
                    Cancel
                </Button>
            </Form>
        </div>
    )
}

export default EditProduct

